TokenPay - Projeto
===============
Como usar:

1) Instale dependências:
   npm install

2) Inicie o servidor:
   npm start

3) Abra no navegador:
   http://localhost:3000

Arquivos:
- public/index.html  -> front-end
- server.js           -> backend (Express + SQLite)
- tokenpay.db         -> será criado automaticamente na raiz quando o servidor rodar
