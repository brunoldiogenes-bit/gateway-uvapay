// server.js
const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'public'))); // /public/index.html

const dbFile = path.join(__dirname,'tokenpay.db');
const db = new sqlite3.Database(dbFile);
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipientKey TEXT,
    amount TEXT,
    payer TEXT,
    desc TEXT,
    txid TEXT,
    expiry INTEGER,
    payload TEXT,
    date TEXT
  )`);
});

app.post('/payments', (req,res)=>{
  const p = req.body;
  const stmt = db.prepare(`INSERT INTO payments (recipientKey,amount,payer,desc,txid,expiry,payload,date) VALUES (?,?,?,?,?,?,?,?)`);
  stmt.run(p.recipientKey,p.amount,p.payer,p.desc,p.txid,p.expiry,p.payload,p.date||new Date().toISOString(), function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({id:this.lastID});
  });
});

app.get('/payments', (req,res)=>{
  db.all('SELECT * FROM payments ORDER BY id ASC', (err,rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});

app.delete('/payments/:id', (req,res)=>{
  const id = Number(req.params.id);
  db.run('DELETE FROM payments WHERE id=?', id, function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({deleted: this.changes});
  });
});

const port = process.env.PORT || 3000;
app.listen(port, ()=>console.log('TokenPay server listening on',port));
